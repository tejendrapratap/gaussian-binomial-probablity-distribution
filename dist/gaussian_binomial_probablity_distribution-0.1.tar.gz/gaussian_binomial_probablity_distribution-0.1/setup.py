from setuptools import setup

setup(name='gaussian_binomial_probablity_distribution',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gaussian_binomial_probablity_distribution'],
      author="Tejendra Pratap",
      author_email="tejendra.pratap.ju@gmail.com",
      zip_safe=False)
